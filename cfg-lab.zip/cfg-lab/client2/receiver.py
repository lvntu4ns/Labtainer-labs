def read_cfg_from_file(filename):
    cfg = {}
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, values = line.split(":")
            key = key.strip()
            values = values.strip()
            if key == "Start":
                cfg[key] = [values]
            else:
                rules = {}
                for pair in values.split(","):
                    bit, word = pair.strip().split("=")
                    rules[word.strip()] = bit.strip()
                cfg[key] = rules
    return cfg

def decode_message(cfg, encoded_text):
    words = encoded_text.split()
    binary_message = ""
    structure = cfg["Start"][0].split()
    
    index = 0
    for part in structure:
        if part in cfg:
            combined_word = words[index]
            while combined_word not in cfg[part] and index + 1 < len(words):
                index += 1
                combined_word += " " + words[index]
            
            if combined_word in cfg[part]:
                binary_message += cfg[part][combined_word]
            else:
                return None
            index += 1

    return binary_to_text(binary_message)

def binary_to_text(binary_message):
    padding_length = (8 - len(binary_message)) % 8
    binary_message += "0" * padding_length

    byte_array = [binary_message[i:i+8] for i in range(0, len(binary_message), 8)]
    return ''.join([chr(int(b, 2)) for b in byte_array])

def main():
    cfg = read_cfg_from_file("cfg.txt")

    with open("message.txt", "r") as f:
        encoded_text = f.read()

    decoded_text = decode_message(cfg, encoded_text)

    if decoded_text:
        print(f"Decoded Message: {decoded_text}")

if __name__ == "__main__":
    main()
