def read_cfg_from_file(filename):
    cfg = {}
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, values = line.split(":")
            key = key.strip()
            values = values.strip()
            if key == "Start":
                cfg[key] = [values]
            else:
                rules = {}
                for pair in values.split(","):
                    bit, word = pair.strip().split("=")
                    rules[word.strip()] = bit.strip()
                cfg[key] = rules
    return cfg

def decode_message(cfg, encoded_text):
    words = encoded_text.split()
    binary_message = ""
    structure = cfg["Start"][0].split()
    
    if len(words) != len(structure):
        print(f"Error: Encoded text has {len(words)} words, but CFG structure expects {len(structure)} words.")
        return None

    for i, part in enumerate(structure):
        word = words[i].lower()  # Chuyển đổi chữ hoa thành chữ thường
        if word in cfg[part]:
            binary_message += cfg[part][word]
        else:
            print(f"Error: Word '{word}' not found in CFG rules for '{part}'.")
            return None

    return binary_to_text(binary_message)

def binary_to_text(binary_message):
    # Chuyển đổi từng byte thành ký tự cho đến khi gặp byte 0 hoặc hết chuỗi
    text = ""
    for i in range(0, len(binary_message), 8):
        byte = binary_message[i:i+8]
        if len(byte) == 8:
            char = chr(int(byte, 2))
            if char == '\0':  # Dừng khi gặp ký tự null
                break
            text += char
    return text

def decode_sentence(cfg, encoded_sentence):
    # Tách câu thành các phần được mã hóa (phân tách bằng dấu chấm)
    encoded_parts = [part.strip() for part in encoded_sentence.split(".") if part.strip()]
    decoded_words = []
    
    for part in encoded_parts:
        # Tách các phần của từ (phân tách bằng dấu phẩy)
        word_parts = [p.strip() for p in part.split(",")]
        decoded_parts = []
        
        for word_part in word_parts:
            decoded_part = decode_message(cfg, word_part)
            if decoded_part:
                decoded_parts.append(decoded_part)
            else:
                return None
        
        # Kết hợp các phần thành từ hoàn chỉnh
        decoded_word = "".join(decoded_parts)
        decoded_words.append(decoded_word)
    
    return " ".join(decoded_words)

def main():
    cfg = read_cfg_from_file("cfg-sim.txt")

    with open("message.txt", "r") as f:
        encoded_text = f.read().strip()

    decoded_text = decode_sentence(cfg, encoded_text)

    if decoded_text:
        print(f"Decoded Message: {decoded_text}")
    else:
        print("Error: Unable to decode the message correctly.")

if __name__ == "__main__":
    main()