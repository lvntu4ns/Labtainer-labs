import language_tool_python
import re
import math
import argparse
import os
import sys
from collections import Counter

def count_sentences(text):
    """Split text into sentences based on punctuation."""
    sentences = re.split(r'[.!?]+', text)
    return [s.strip() for s in sentences if s.strip()]

def calculate_sentence_repetition_score(sentences, num_sentences):
    """Calculate repetition score based on word repetition across sentences, with threshold."""
    word_history = Counter()
    repetition_scores = []
    word_sentence_map = {}  # Track which sentences contain each word
    threshold = 0.5  # Threshold: word appears in >50% of sentences

    for i, sentence in enumerate(sentences):
        words = [word for word in sentence.lower().split() if len(word) >= 3]  # Exclude short words
        if not words:
            repetition_scores.append(0)
            continue

        # Calculate repetition score for current sentence
        repetition_count = 0
        for word in words:
            if word in word_history:
                repetition_count += word_history[word]
            # Update sentence map
            if word not in word_sentence_map:
                word_sentence_map[word] = []
            if i + 1 not in word_sentence_map[word]:
                word_sentence_map[word].append(i + 1)

        # Update word history
        word_history.update(words)

        # Repetition score: total repetitions / number of words
        repetition_score = repetition_count / len(words) if words else 0

        # Apply threshold: boost score if a word appears in >50% of sentences
        for word in set(words):
            sentence_count = len(word_sentence_map[word])
            if num_sentences > 0 and sentence_count / num_sentences > threshold:
                repetition_score += 0.2  # Boost score for high repetition

        repetition_scores.append(repetition_score)

    # Average repetition score across sentences
    avg_repetition_score = sum(repetition_scores) / len(repetition_scores) if repetition_scores else 0
    # Normalize and amplify for sensitivity
    avg_repetition_score = min(avg_repetition_score * 1.5, 1.0)  # Cap at 1.0
    return avg_repetition_score, word_sentence_map

def calculate_max_repetition_freq(words):
    """Calculate maximum word repetition frequency."""
    if not words:
        return 0
    word_count = Counter(word for word in words if len(word) >= 3)  # Exclude short words
    max_count = max(word_count.values()) if word_count else 0
    total_words = len([word for word in words if len(word) >= 3])
    return max_count / total_words if total_words > 0 else 0

def calculate_suspicion_score(num_errors, num_sentences, num_words, sentence_repetition_score, max_repetition_freq, alpha=0.3, beta=0.2, epsilon=0.5):
    """Calculate suspicion score focusing on grammar errors and word repetition."""
    error_per_sentence = num_errors / num_sentences if num_sentences else 0
    error_per_word = num_errors / num_words if num_words else 0
    # Combine features
    score = (
        alpha * error_per_sentence +
        beta * error_per_word +
        epsilon * (sentence_repetition_score + max_repetition_freq) / 2  # Average repetition features
    )
    return score, error_per_sentence, error_per_word, sentence_repetition_score, max_repetition_freq

def sigmoid(score, k=5.0, theta=0.4):
    """Convert suspicion score to probability using sigmoid function."""
    return 1 / (1 + math.exp(-k * (score - theta)))

def get_suspicion_level(probability):
    """Determine suspicion level based on probability."""
    if probability < 0.45:
        return "LOW"
    elif probability < 0.60:
        return "MEDIUM"
    elif probability < 0.80:
        return "HIGH"
    else:
        return "VERY HIGH"

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Detect potential hidden messages in a text file using CFG method")
    parser.add_argument("-m", "--message", required=True, help="Path to the text file to analyze")
    parser.add_argument("-l", "--language", default="en-US", help="Language for grammar checking (default: en-US)")
    parser.add_argument("-o", "--output", help="Path to save analysis results (optional)")
    args = parser.parse_args()

    # Check if input file exists and is readable
    if not os.path.isfile(args.message):
        print(f"Error: File '{args.message}' does not exist.")
        sys.exit(1)
    if not os.access(args.message, os.R_OK):
        print(f"Error: File '{args.message}' is not readable.")
        sys.exit(1)

    # Read text from file
    try:
        with open(args.message, 'r', encoding='utf-8') as f:
            text = f.read()
    except Exception as e:
        print(f"Error: Could not read file '{args.message}': {e}")
        sys.exit(1)

    # Initialize LanguageTool
    try:
        tool = language_tool_python.LanguageToolPublicAPI(args.language)
    except Exception as e:
        print(f"Error: Could not initialize LanguageTool for language '{args.language}': {e}")
        sys.exit(1)

    # Analyze text
    matches = tool.check(text)
    num_errors = len(matches)
    sentences = count_sentences(text)
    num_sentences = len(sentences)
    words = text.lower().split()
    num_words = len(words)

    # Analyze error types
    error_types = [match.ruleId for match in matches]
    error_type_freq = Counter(error_types)

    # Calculate sentence repetition score
    sentence_repetition_score, word_sentence_map = calculate_sentence_repetition_score(sentences, num_sentences)

    # Calculate maximum repetition frequency
    max_repetition_freq = calculate_max_repetition_freq(words)

    # Prepare output
    output_lines = []
    output_lines.append(f"Analysis of '{args.message}':")
    output_lines.append(f"Total sentences: {num_sentences}")
    output_lines.append(f"Total words: {num_words}")
    output_lines.append(f"Total errors: {num_errors}")

    # Print detected errors
    if num_errors > 0:
        output_lines.append("Detected errors:")
        for i, match in enumerate(matches, 1):
            output_lines.append(f"  {i}. {match.ruleId}: {match.message} (at position {match.offset})")
            output_lines.append(f"     Context: {match.context}")
        output_lines.append("Error type frequency:")
        for error_type, count in error_type_freq.items():
            output_lines.append(f"  {error_type}: {count}")
    else:
        output_lines.append("No grammatical errors detected.")

    # Print word repetition details
    if word_sentence_map:
        output_lines.append("Words repeated across sentences:")
        # Sort by total frequency
        word_freq = Counter({word: len(sentences) for word, sentences in word_sentence_map.items()})
        high_repetition_words = []
        for word, count in word_freq.most_common(5):
            if count > 1:  # Only show words that appear in multiple sentences
                sentences_list = word_sentence_map[word]
                sentence_ratio = len(sentences_list) / num_sentences if num_sentences > 0 else 0
                output_lines.append(f"  {word}: {count} times, in sentences {sentences_list} ({sentence_ratio:.2f} of sentences)")
                if sentence_ratio > 0.5:
                    high_repetition_words.append(word)
        if high_repetition_words:
            output_lines.append(f"Warning: High repetition detected for word(s): {', '.join(high_repetition_words)}")

    # Calculate suspicion score and probability
    score, err_sent, err_word, sent_rep_score, max_rep_freq = calculate_suspicion_score(
        num_errors, num_sentences, num_words, sentence_repetition_score, max_repetition_freq
    )
    probability = sigmoid(score)
    suspicion_level = get_suspicion_level(probability)

    # Add analysis results
    output_lines.append(f"[+] Average errors per sentence: {err_sent:.2f}")
    output_lines.append(f"[+] Error rate per word: {err_word * 100:.2f}%")
    output_lines.append(f"[+] Sentence repetition score: {sent_rep_score:.2f}")
    output_lines.append(f"[+] Max repetition frequency: {max_rep_freq:.2f}")
    output_lines.append(f"[+] Suspicion score: {score:.2f}")
    output_lines.append(f"[+] Probability of hidden message: {probability:.2f}")
    output_lines.append(f"[+] Suspicion level: {suspicion_level}")
    output_lines.append(f"[+] Summary: The text has a {probability*100:.2f}% chance of containing a hidden message using CFG method")

    # Print results to console
    for line in output_lines:
        print(line)

    # Save results to output file if specified
    if args.output:
        try:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write("\n".join(output_lines))
            print(f"Results saved to '{args.output}'")
        except Exception as e:
            print(f"Error: Could not save results to '{args.output}': {e}")

if __name__ == "__main__":
    main()
