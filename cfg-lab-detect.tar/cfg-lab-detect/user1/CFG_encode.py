import os
import argparse

def read_cfg_from_file(filename):
    cfg = {}
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, values = line.split(":")
            key = key.strip()
            values = values.strip()
            if key == "Start":
                cfg[key] = [values]
            else:
                rules = {}
                for pair in values.split(","):
                    bit, word = pair.strip().split("=")
                    rules[bit.strip()] = word.strip() 
                cfg[key] = rules
    return cfg

def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

def encode_message(cfg, binary_message):
    words = []
    structure = cfg["Start"][0].split()
    index = 0
    
    # Tính tổng bit cần thiết từ CFG
    total_bits_needed = sum(max(len(k) for k in cfg[part].keys()) for part in structure if part in cfg)
    # Đảm bảo chuỗi bit đủ dài cho từ dài nhất (16 ký tự = 128 bit)
    binary_message = binary_message.ljust(total_bits_needed, '0')

    for part in structure:
        if part in cfg:
            choices = cfg[part]
            bit_length = max(len(k) for k in choices.keys())
            bit_chunk = binary_message[index:index + bit_length]
            
            if bit_chunk in choices:
                words.append(choices[bit_chunk])
            else:
                print(f"Warning: Bit chunk '{bit_chunk}' not in {part}, using default.")
                words.append(list(choices.values())[0])
            index += bit_length

    return ' '.join(words)

def encode_sentence(cfg, sentence):
    # Tách câu thành các từ
    words = sentence.split()
    encoded_words = []
    
    for i, word in enumerate(words):
        # Kiểm tra độ dài của từ
        if len(word) > 16:
            print(f"Error: Word '{word}' is too long. Maximum 16 characters allowed per word.")
            return None
            
        # Chia từ thành các phần 8 ký tự
        parts = [word[j:j+8] for j in range(0, len(word), 8)]
        encoded_parts = []
        
        for part in parts:
            # Mã hóa từng phần
            binary_word = text_to_binary(part)
            encoded_part = encode_message(cfg, binary_word)
            encoded_parts.append(encoded_part)
        
        # Kết hợp các phần với dấu phẩy
        encoded_word = ", ".join(encoded_parts) + "."
        
        # Viết hoa chữ cái đầu của câu đầu tiên
        if i == 0:
            encoded_word = encoded_word[0].upper() + encoded_word[1:]
        # Viết hoa chữ cái đầu sau dấu chấm
        else:
            encoded_word = " " + encoded_word[0].upper() + encoded_word[1:]
        encoded_words.append(encoded_word)
    
    # Kết hợp các câu đã mã hóa
    return "".join(encoded_words)

def main():
    parser = argparse.ArgumentParser(description="Encode a secret message using CFG.")
    parser.add_argument("-m", "--message", type=str, help="The secret message to encode (a sentence).")
    args = parser.parse_args()

    cfg = read_cfg_from_file("cfg.txt")

    if args.message:
        secret_message = args.message
    else:
        print("Please provide a message using the -m or --message flag.")
        return

    encoded_text = encode_sentence(cfg, secret_message)
    if encoded_text:
        print("Encoded Text: " + encoded_text)
        with open("message.txt", "w") as f:
            f.write(encoded_text)
    else:
        print("Error: Unable to encode the message.")

if __name__ == "__main__":
    main()