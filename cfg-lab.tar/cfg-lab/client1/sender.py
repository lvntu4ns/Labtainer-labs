import os
import argparse

def read_cfg_from_file(filename):
    cfg = {}
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key, values = line.split(":")
            key = key.strip()
            values = values.strip()
            if key == "Start":
                cfg[key] = [values]
            else:
                rules = {}
                for pair in values.split(","):
                    bit, word = pair.strip().split("=")
                    rules[bit.strip()] = word.strip() 
                cfg[key] = rules
    return cfg

def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

def encode_message(cfg, binary_message):
    words = []
    structure = cfg["Start"][0].split()
    index = 0
    
    for part in structure:
        if part in cfg:
            choices = cfg[part]
            bit_length = max(len(k) for k in choices.keys())
            bit_chunk = binary_message[index:index + bit_length]

            if len(bit_chunk) < bit_length:
                bit_chunk += '0' * (bit_length - len(bit_chunk))
            
            if bit_chunk in choices:
                words.append(choices[bit_chunk])
                index += bit_length
            else:
                words.append(list(choices.values())[0])
                index += bit_length
    
    return ' '.join(words)

def main():
    parser = argparse.ArgumentParser(description="Encode a secret message using CFG.")
    parser.add_argument("-m", "--message", type=str, help="The secret message to encode (max 4 characters).")
    args = parser.parse_args()

    cfg = read_cfg_from_file("cfg.txt")

    if args.message:
        secret_message = args.message
    else:
        print("Please provide a message using the -m or --message flag.")
        return

    if len(secret_message) > 4:
        print("Too Long!")
        return

    binary_secret = text_to_binary(secret_message)
    print("Binary Secret: " + binary_secret)

    encoded_text = encode_message(cfg, binary_secret)
    print("Encoded Text: " + encoded_text)

    with open("message.txt", "w") as f:
        f.write(encoded_text)

if __name__ == "__main__":
    main()
